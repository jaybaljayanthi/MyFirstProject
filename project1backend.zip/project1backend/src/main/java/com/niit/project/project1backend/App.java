package com.niit.project.project1backend;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.configuration.DBConfiguration;
import com.niit.dao.ProductDao;
import com.niit.dao.ProductDaoImpl;
import com.niit.models.Product;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
        ApplicationContext context=new AnnotationConfigApplicationContext(DBConfiguration.class,ProductDaoImpl.class);
        ProductDao productDao=(ProductDao)context.getBean("productDaoImpl");
        
      /*  List all Products
       * 
       * 
       List<Product> products=productDao.getAllProducts();
        for(Product p:products)
        {
        	System.out.println(p.getId()+""+p.getProductdesc()+""+p.getPrice()+""+p.getQuantity());
       
        }
        */ 
        
        
        //delete the product
        
        
       // productDao.deleteProduct(97);
       // productDao.deleteProduct(98);   
       // productDao.deleteProduct(99);
      //  productDao.deleteProduct(129);
         
        
       /* save the product
        
        
        Product product=new Product();
        product.setProductname("Introduction");
        product.setProductdesc("3rd Edition");
        product.setPrice(200);
        product.setQuantity(15);
        productDao.saveProduct(product);
        */
        
        
        //update a product
        
        Product product=productDao.getProduct(4);
        product.setPrice(300);
        product.setQuantity(20);
        productDao.updateProduct(product);
    }
}
