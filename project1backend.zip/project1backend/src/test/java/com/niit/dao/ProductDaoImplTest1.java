package com.niit.dao;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.configuration.DBConfiguration;
import com.niit.models.Product;

import junit.framework.TestCase;

public class ProductDaoImplTest1 extends TestCase {
	ApplicationContext context=new AnnotationConfigApplicationContext(DBConfiguration.class,ProductDaoImpl.class);
    ProductDao productDao=(ProductDao)context.getBean("productDaoImpl");


	public void testSaveProduct() {
		
		Product product=productDao.getProduct(3);
		product.setPrice(100);
		product.setQuantity(1);
		product.setProductname("WaterBottle");
		product.setProductdesc("Blue color");
		product=productDao.saveProduct(product);
		
		
	}

	public void testGetProduct() {
	
	}

	public void testUpdateProduct() {
		
		Product product=productDao.getProduct(3);
		product.setPrice(2000);
		product.setQuantity(25);
		productDao.updateProduct(product);
		assertTrue(product.getPrice()==2000);
		assertTrue(product.getQuantity()==25);
		
	}

	public void testDeleteProduct() 
	{
		
	}
	public void testGetAllProducts()
	{
		List<Product> products=productDao.getAllProducts();
		assertTrue(products.size()>0);
		assertFalse(products.isEmpty());
		
		
	}

}
